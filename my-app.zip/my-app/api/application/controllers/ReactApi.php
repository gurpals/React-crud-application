	
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ReactApi extends CI_Controller {

	public function __construct()
	{
		header("Access-Control-Allow-Origin: *");
		parent::__construct();
		$this->load->model('reactapi_model');
	}

	public function products()
	{ 
		
		header("Access-Control-Allow-Origin: *");
		$allProducts = $this->reactapi_model->get_products();

		$this->output
		->set_content_type('application/json')
		->set_output(json_encode($allProducts));
	}

	public function getProduct()
	{ header("Access-Control-Allow-Origin: *");
	$productId=$this->input->post('productId');
	header("Access-Control-Allow-Origin: *");

	$Products = $this->reactapi_model->fetchproduct($productId);

	$this->output
	->set_content_type('application/json')
	->set_output(json_encode($Products));
}

public function editProduct()
{ 
	$editData=$this->input->post();



		//$products = $this->reactapi_model->get_Product($productId);

	$this->output
	->set_content_type('application/json')
	->set_output(json_encode($editData));
}
public function add_product	()
{ 
	header("Access-Control-Allow-Origin: *");
	$responseData=array();
	$processData['product_name']=$this->input->post('product_name');
	$processData['sku']=$this->input->post('sku');
	$processData['price']=$this->input->post('price');
	$processData['is_active']=1;
	if($this->reactapi_model->add_product($processData))
	{
		$insert_id=$this->db->insert_id();
		$responseData['status']=true;
		$responseData['id']=$insert_id;
		$responseData['Message']='Product added!';
	}else
	{
		$insert_id=$this->db->insert_id();
		$responseData['status']=false;
		$responseData['id']=null;
		$responseData['Message']='Product not added!';
	}


	echo   json_encode($responseData);
}

public function update_product	()
{ 
	header("Access-Control-Allow-Origin: *");
	$responseData=array();
	$processData['product_name']=$this->input->post('product_name');
	$processData['sku']=$this->input->post('sku');
	$processData['price']=$this->input->post('price');
	$processData['id']=$this->input->post('product_id');
	$processData['is_active']=1;

	if($this->reactapi_model->update_product($processData))
	{
		$insert_id=$this->db->insert_id();
		$responseData['status']=true;
		$responseData['id']=$insert_id;
		$responseData['Message']='Product updated!';
	}else
	{
		$insert_id=$this->db->insert_id();
		$responseData['status']=false;
		$responseData['id']=null;
		$responseData['Message']='Product not added!';
	}


	echo   json_encode($responseData);
}
public function delete_product()
{ 
	header("Access-Control-Allow-Origin: *");
	$responseData=array();
	$processData['id']=$this->input->post('productId');
	$processData['is_active']=0;

	if($this->reactapi_model->update_product($processData))
	{
		$insert_id=$this->db->insert_id();
		$responseData['status']=true;
		$responseData['Message']='Product Deleted!';
	}else
	{
		$insert_id=$this->db->insert_id();
		$responseData['status']=false;
		$responseData['Message']='Product not Deleted!';
	}


	echo   json_encode($responseData);
}
}
?>
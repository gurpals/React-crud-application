	
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Reactapi_model extends CI_model {
	

	public function __construct() {
		$this->load->database();

	}
	public function get_products()
	{

		$this->db->where('is_active', 1);
		$query = $this->db->get('products');
		return $query->result();
	}
	public function fetchproduct($id)
	{

		$this->db->where('id',$id);
		$query = $this->db->get('products');
		return $query->result();
	}
	public function add_product($data)
	{
		$getResponse=$this->db->insert('products', $data);
		return  $getResponse;
	}
	public function update_product($data)
	{
		
		$this->db->where('id', $data['id']);
		$getResponse=$this->db->update('products',$data);
		return  $getResponse;
	}

}
?>
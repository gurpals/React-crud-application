import React from 'react';
import AllProducts from './AllProducts';
class AddProduct extends React.Component {
	constructor(props) {
		super(props);
		this.state = ({
			Message: '',
			products:[],
			price:'',
			sku:'',
			product_name:'',
			btn_title:'Add Product'
		})
		this.handleSubmit = this.handleSubmit.bind(this);
		console.log(window.topicText);
	}
	onProductNameChange(e) {
		this.setState({product_name: e.target.value});
	}

	onSkuChange(e) {
		this.setState({sku: e.target.value});
	}

	onPriceChange (e) {
		console.log(e.target.value);
		this.setState({price: e.target.value});
	}

	handleSubmit(event) {
		event.preventDefault();
		console.log(this.state.id);
		if(this.state.id===undefined)
		{
			const data = new FormData(event.target);

			fetch('http://localhost/React_website/api/index.php/ReactApi/add_product',{
				method: 'POST',
				body: data,
			}).then(res => res.json())
			.then(res => this.setState({ Message: 'Product Added',btn_title:'Add Product' }));
			//this.componentDidMount();
		}else
		{
			const data = new FormData();
			data.append('product_name',this.state.product_name);
			data.append('sku',this.state.sku);
			data.append('product_id',this.state.id);
			data.append('price',this.state.price);

			fetch('http://localhost/React_website/api/index.php/ReactApi/update_product',{
				method: 'POST',
				body: data,
			}).then(res => res.json())
			.then(res => this.setState({ Message: 'Product Updated' ,btn_title:'Update Product'}));
			//this.componentDidMount();
		}
	}
	
	

	render() {
		const { error, products} = this.state;

		let $Btn_data = null;
		let $message_data = null;
		if (this.state.edit) {
			$Btn_data = (<button className="btn btn-success" onClick={() => this.clearform()} >Add Product</button>);
		}

		if (this.state.Message!=='') {
			$message_data = (<div className='alert alert-success'>{this.state.Message}</div>);
		}
		return (

		<React.Fragment>
		<div className='col-md-4'>
		<form onSubmit={this.handleSubmit}>
		{$message_data}
		<label htmlFor="name">Product Name</label>
		<input onChange={(e) => {this.onProductNameChange(e)}}   className='form-control' id="product_name" name="product_name" type="text" value={this.state.product_name} />

		<label htmlFor="sku">Sku</label>
		<input onChange={(e) => {this.onSkuChange(e)}}   className='form-control' id="sku" value={this.state.sku} name="sku" type="text" />

		<label htmlFor="price">Price</label>
		<input onChange={(e) => {this.onPriceChange(e)}}  className='form-control' id="price" value={this.state.price} name="price" type="text" />

		<button className='btn btn-primary'>{this.state.btn_title}</button>
		</form>
		</div>
		</React.Fragment>
		);
	}
}


export default AddProduct;
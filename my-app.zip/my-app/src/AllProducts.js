import React from 'react';
import { BrowserRouter as Router, Route,Redirect,Switch,Link } from 'react-router-dom';
class AddProduct extends React.Component {
	constructor(props) {
		super(props);
		this.state = ({
			Message: '',
			products:[],
			price:'',
			sku:'',
			product_name:'',
			btn_title:'Add Product'
		})
		
	}
	onProductNameChange(e) {
		this.setState({product_name: e.target.value});
	}

	onSkuChange(e) {
		this.setState({sku: e.target.value});
	}

	onPriceChange (e) {
		console.log(e.target.value);
		this.setState({price: e.target.value});
	}
	console.log(APP_URL);
	deleteProduct(productId) {
		const { products } = this.state;

		const apiUrl = APP_URL+'api/index.php/ReactApi/delete_product';
		const formData = new FormData();
		formData.append('productId', productId);

		const options = {
			method: 'POST',
			body: formData
		}

		fetch(apiUrl, options)
		.then(result => result.json())
		.then(
			(result) => {

				this.setState({
					Message: result.Message
				});
				this.componentDidMount();
			},
			(error) => {
				this.setState({ error });
			}
			)
	}
	componentDidMount() {
		const apiUrl = APP_URL+'api/index.php/ReactApi/products';
		console.log(APP_URL);
		fetch(apiUrl)
		.then(res => res.json())
		.then(
			(res) => {
				this.setState({
					products: res
				})
			}
			)

	}

	render() {
		const { error, products} = this.state;

		let $Btn_data = null;
		let $message_data = null;
		if (this.state.edit) {
			$Btn_data = (<button className="btn btn-success" onClick={() => this.clearform()} >Add Product</button>);
		}

		if (this.state.Message!=='') {
			$message_data = (<div className='alert alert-success'>{this.state.Message}</div>);
		}
		return (

		<React.Fragment>
		<hr/>
		<h2>All Products</h2>

		<table className='table table-striped'>
		<thead>
		<tr>
		<th>Product No.</th>
		<th>Product Name</th>
		<th>Product Sku</th>
		<th>Product Price</th>
		<th>Action</th></tr>
		</thead>
		<tbody>
		{products.map((product,index) => (
			<tr key={product.id}>
			<td>{index+1}</td>
			<td>{product.product_name}</td>
			<td>{product.sku}</td>
			<td>{product.price}</td>
			<td>
			<Link className='btn btn-success' to={
				{ 
					pathname: "/UpateProduct/" + product.id
				}
			}>Edit</Link>
			&nbsp;<button className='btn btn-danger' variant="danger" onClick={(e) => {if (window.confirm('Are you sure you wish to delete this product?')) this.deleteProduct(product.id)}}>Delete</button>
			</td>
			</tr>
			))}
			</tbody>
			</table>
			</React.Fragment>
			);
		}
	}


	export default AddProduct;
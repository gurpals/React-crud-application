import React from 'react';
import AddProduct from './AddProduct';
import AllProducts from './AllProducts';
import Routes from './Routes';
import { BrowserRouter as Router, Route,Redirect,Switch,Link } from 'react-router-dom';
class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = ({
      Message: '',
      products:[],
      price:'',
      sku:'',
      product_name:'',
      btn_title:'Add Product'
    })

    
  }

  render() {
    const { error, products} = this.state;
    

    let $Btn_data = null;
    let $message_data = null;
    if (this.state.edit) {
      $Btn_data = (<button className="btn btn-success" onClick={() => this.clearform()} >Add Product</button>);
    }
    
    if (this.state.Message!=='') {
      $message_data = (<div className='alert alert-success'>{this.state.Message}</div>);
    }
    return (
    <Router>  
    <Link className='btn btn-success ' to='/AddProduct'>Add Product</Link>
    <Link className='btn btn-success ' to='/'>View Product</Link>
    <Routes/>
    </Router>
    );
  }
}


export default App;
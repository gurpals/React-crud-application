import React from "react";
import { Route, Switch } from "react-router-dom";

import AddProduct from "./AddProduct";
import AllProducts from "./AllProducts";
import UpateProduct from "./UpateProduct";



class Routes extends React.Component {
  render() {
   window.APP_URL= location.protocol + '//' + location.hostname + location.pathname;
   return (
    <Switch>
    <Route exact path="/" component={AllProducts} />
    <Route exact path="/AddProduct" component={AddProduct} />
    <Route exact path="/UpateProduct/:id" component={UpateProduct} />


    <Route
    render={function () {
      return <h1>Not Found</h1>;
    }}
    />
    </Switch>
    );
  }
}

export default Routes;

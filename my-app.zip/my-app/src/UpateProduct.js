import React from 'react';
import AllProducts from './AllProducts';
class AddProduct extends React.Component {
	constructor(props) {
		super(props);
		this.state = ({
			Message: '',
			products:[],
			price:'',
			sku:'',
			product_name:'',
			btn_title:'Add Product'
		})
		this.handleSubmit = this.handleSubmit.bind(this);
		this.state = {
			productid: props.match.params.id
		}
	}
	onProductNameChange(e) {
		this.setState({product_name: e.target.value});
	}

	onSkuChange(e) {
		this.setState({sku: e.target.value});
	}

	onPriceChange (e) {
		console.log(e.target.value);
		this.setState({price: e.target.value});
	}

	handleSubmit(event) {
		event.preventDefault();		
		const data = new FormData();
		data.append('product_name',this.state.product_name);
		data.append('sku',this.state.sku);
		data.append('product_id',this.state.id);
		data.append('price',this.state.price);

		fetch('http://localhost/React_website/api/index.php/ReactApi/update_product',{
			method: 'POST',
			body: data,
		}).then(res => res.json())
		.then(res => this.setState({ Message: 'Product Updated' ,btn_title:'Update Product'}));
			//this.componentDidMount();

		}

		componentDidMount (){

			const apiUrl = 'http://localhost/React_website/api/index.php/ReactApi/getProduct';
			const formData = new FormData();
			formData.append('productId', this.state.productid);
			this.setState({btn_title:'Update Product',edit:true})
			const options = {
				method: 'POST',
				body: formData
			}

			fetch(apiUrl, options)
			.then(res => res.json())
			.then(
				(res) => {
					this.setState({
						product_name: res[0].product_name,
						sku: res[0].sku,
						id: res[0].id,
						price:res[0].price
					});

				},
				(error) => {
					this.setState({ error });
				}
				)

		}

		render() {
			const { error, products} = this.state;

			let $Btn_data = null;
			let $message_data = null;
			if (this.state.edit) {
				$Btn_data = (<button className="btn btn-success" onClick={() => this.clearform()} >Add Product</button>);
			}

			if (this.state.Message!=='') {
				$message_data = (<div className='alert alert-success'>{this.state.Message}</div>);
			}
			return (

			<React.Fragment>
			<form onSubmit={this.handleSubmit}>
			{$message_data}
			<label htmlFor="username">Enter product name</label>
			<input onChange={(e) => {this.onProductNameChange(e)}}   className='form-control' id="product_name" name="product_name" type="text" value={this.state.product_name} />

			<label htmlFor="email">Enter your sku</label>
			<input onChange={(e) => {this.onSkuChange(e)}}   className='form-control' id="sku" value={this.state.sku} name="sku" type="text" />

			<label htmlFor="birthdate">Enter your price</label>
			<input onChange={(e) => {this.onPriceChange(e)}}  className='form-control' id="price" value={this.state.price} name="price" type="text" />

			<button className='btn btn-primary'>Update Product</button>
			</form>
			</React.Fragment>
			);
		}
	}


	export default AddProduct;